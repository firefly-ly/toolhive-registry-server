---
name: Echo Skill
description: A demo skill that echoes input
---

# Echo Skill

A demo skill that echoes input

Exported from ToolHive Cloud UI as a self-describing skill package.
