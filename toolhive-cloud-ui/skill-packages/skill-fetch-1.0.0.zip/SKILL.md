---
name: Fetch Skill
description: Fetch web content as a skill
---

# Fetch Skill

Fetch web content as a skill

Exported from ToolHive Cloud UI as a self-describing skill package.
